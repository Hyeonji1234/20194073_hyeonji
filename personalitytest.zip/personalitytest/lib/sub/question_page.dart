import 'dart:convert';
import 'package:flutter/material.dart';
import '../detail/detail_page.dart';
import '../ads/banner_ad_widget.dart';

class QuestionPage extends StatefulWidget {
  final Map<String, dynamic> question; // JSON 데이터

  const QuestionPage({super.key, required this.question});

  @override
  State<QuestionPage> createState() => _QuestionPageState();
}

class _QuestionPageState extends State<QuestionPage> {
  int? selected; // 선택된 답 항목 index

  @override
  Widget build(BuildContext context) {
    final String title = widget.question['title'];
    final String question = widget.question['question'];
    final List selects = widget.question['selects'];
    final List answers = widget.question['answer']; // index로 접근

    return Scaffold(
      backgroundColor: const Color(0xfff8f5ff),

      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontSize: 18,fontWeight: FontWeight.bold)),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 0,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              question,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),

            const SizedBox(height: 30),

            // 🔥 선택지 리스트
            ...List.generate(selects.length, (index) {
              return Center(
                child: GestureDetector(
                  onTap: ()=> setState(()=> selected = index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    margin: const EdgeInsets.only(bottom: 16),
                    width: double.infinity,
                    constraints: const BoxConstraints(maxWidth: 320),
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),

                    decoration: BoxDecoration(
                      color: selected == index ? Colors.deepPurple.shade100 : Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: selected == index ? Colors.deepPurple : Colors.grey.shade300,
                        width: selected == index ? 2 : 1,
                      ),
                      boxShadow: selected == index
                          ? [BoxShadow(color: Colors.deepPurple.withOpacity(0.25), blurRadius: 8)]
                          : [],
                    ),

                    child: Text(
                      selects[index],
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: selected == index ? Colors.deepPurple : Colors.black87,
                      ),
                    ),
                  ),
                ),
              );
            }),

            const SizedBox(height: 40),

            // 🔥 결과 보기 버튼
            Center(
              child: ElevatedButton(
                onPressed: selected == null ? null : () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => DetailPage(
                        answer: answers[selected!],
                        testTitle: title,
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  disabledBackgroundColor: Colors.grey.shade400,
                  padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text("결과 보기", style: TextStyle(fontSize: 18,color: Colors.white)),
              ),
            )
          ],
        ),
      ),
      bottomNavigationBar: const BannerAdWidget(),
    );
  }
}
