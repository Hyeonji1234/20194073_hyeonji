import 'package:flutter/material.dart';
import 'package:kakao_flutter_sdk_share/kakao_flutter_sdk_share.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import '../ads/banner_ad_widget.dart';
import '../main/mainlist_page.dart';

class DetailPage extends StatelessWidget {
  final String answer;     // 결과 내용
  final String testTitle;  // 테스트 제목

  const DetailPage({
    super.key,
    required this.answer,
    required this.testTitle,
  });

  /// 🔥 카카오 공유 함수
  Future<void> shareKakao() async {
    FeedTemplate template = FeedTemplate(
      content: Content(
        title: "📌 $testTitle 결과",
        description: answer,
        imageUrl: Uri.parse("https://i.ibb.co/ydgcvJY/psychology.png"), // 기본 이미지
        link: Link(
          mobileWebUrl: Uri.parse("https://example.com"),
          webUrl: Uri.parse("https://example.com"),
        ),
      ),
      buttons: [
        Button(
          title: "테스트 다시 하기",
          link: Link(
            mobileWebUrl: Uri.parse("https://example.com"),
            webUrl: Uri.parse("https://example.com"),
          ),
        )
      ],
    );

    try {
      bool installed = await ShareClient.instance.isKakaoTalkSharingAvailable();

      if (installed) {
        Uri url = await ShareClient.instance.shareDefault(template: template);
        await ShareClient.instance.launchKakaoTalk(url);
      } else {
        Uri webUrl = await WebSharerClient.instance.makeDefaultUrl(template: template);
        await launchUrl(webUrl, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      print("❌ 카카오 공유 실패 → 일반 공유 fallback: $e");
      Share.share("📌 [$testTitle]\n$answer");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff8f5ff),

      appBar: AppBar(
        title: Text(testTitle, style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),

      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),

          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [

              const Icon(Icons.psychology, size: 50, color: Colors.deepPurple),
              const SizedBox(height: 16),

              const Text("🧠 결과",
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.deepPurple),
              ),
              const SizedBox(height: 30),

              // 결과 카드 박스
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: LinearGradient(colors: [
                    Colors.deepPurple.shade300,
                    Colors.amber.shade300,
                  ]),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.deepPurple.withOpacity(.35),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    )
                  ],
                ),
                child: Text(
                  answer,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    height: 1.5,
                  ),
                ),
              ),

              const SizedBox(height: 60),

              /// 🔥 카카오 공유 버튼
              ElevatedButton.icon(
                onPressed: shareKakao,
                icon: const Icon(Icons.chat_bubble, color: Colors.brown),
                label: const Text("카카오톡 공유"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 20),

              /// 목록으로
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const MainPage()),
                        (route) => false,
                  );
                },
                icon: const Icon(Icons.list),
                label: const Text("목록으로"),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.deepPurple, width: 2),
                  foregroundColor: Colors.deepPurple,
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              )
            ],
          ),
        ),
      ),
      bottomNavigationBar: const BannerAdWidget(),
    );
  }
}
