import 'package:flutter/material.dart';
import 'dart:convert';
import '../sub/question_page.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/services.dart';
import '../ads/banner_ad_widget.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final FirebaseRemoteConfig remoteConfig = FirebaseRemoteConfig.instance;
  final FirebaseDatabase database = FirebaseDatabase.instance;
  late DatabaseReference _testRef;

  late Future<List<Map<String,dynamic>>> _loadFuture;

  /// 📌 (1) 로컬 JSON을 읽어서 Firebase + 앱에 사용 가능한 리스트 반환
  Future<List<Map<String, dynamic>>> loadTests() async {
    final String listData = await rootBundle.loadString('res/api/list.json');
    final listJson = json.decode(listData);

    List<Map<String,dynamic>> result = [];

    for (var item in listJson["questions"]) {
      String file = item["file"];
      String fileData = await rootBundle.loadString('res/api/$file.json');
      result.add(json.decode(fileData));
    }

    return result;
  }

  /// 📌 (2) 로컬 JSON → Firebase Realtime DB 자동 업로드
  Future<void> uploadLocalJsonToFirebase() async {
    final String listData = await rootBundle.loadString('res/api/list.json');
    final listJson = json.decode(listData);

    for (var item in listJson["questions"]) {
      String file = item["file"];                     // test1, mbti, test2 등 파일명
      String fileData = await rootBundle.loadString('res/api/$file.json');
      final data = json.decode(fileData);

      /// push() ❌ → 실행할 때마다 중복생성됨
      /// child(fileName) ✔ 파일명으로 저장되며 덮어쓰기 가능
      await database.ref("test/$file").set(data);
    }

    print("🔥 로컬 JSON → Firebase 자동 업로드 완료!");
  }

  @override
  void initState() {
    super.initState();
    _testRef = database.ref("test");

    /// 🔥 앱 실행 시 1번만 주석 풀고 업로드 사용 → 이후엔 주석 추천
    uploadLocalJsonToFirebase();   // << 여기가 업로드 기능 ✨

    _loadFuture = loadTests();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff8f5ff),

      appBar: AppBar(
        title: Text(
          "✨ 잼나는 심리테스트",
          style: const TextStyle(
            fontWeight: FontWeight.w900,
            fontSize: 22,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 0,
      ),

      body: FutureBuilder(
        future: _loadFuture,
        builder: (context, snapshot) {
          if(snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: Colors.deepPurple));
          }

          if(!snapshot.hasData || (snapshot.data as List).isEmpty) {
            return const Center(
              child: Text("📭 등록된 테스트가 없어요!", style: TextStyle(fontSize: 18)),
            );
          }

          List data = snapshot.data as List;

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            itemCount: data.length,
            itemBuilder: (context, index) {

              return GestureDetector(
                onTap: () {
                  FirebaseAnalytics.instance.logEvent(
                    name: "test_select",
                    parameters: {"title": data[index]["title"]},
                  );

                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => QuestionPage(question: data[index])),
                  );
                },

                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOut,
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: LinearGradient(
                        colors: [Colors.deepPurple.shade300, Colors.amber.shade300],
                      ),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 8,
                            spreadRadius: 1,
                            offset: const Offset(2,4)
                        )
                      ]
                  ),

                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    title: Text(
                      data[index]['title'],
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white, size: 18),
                  ),
                ),
              );
            },
          );
        },
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.deepPurple,
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("🚧 테스트 추가 기능 준비중"))
          );
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
      bottomNavigationBar: const BannerAdWidget(),
    );
  }
}
