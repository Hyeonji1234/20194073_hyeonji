package com.example.personalitytest

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
